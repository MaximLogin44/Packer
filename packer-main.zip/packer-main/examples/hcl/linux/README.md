# Basic HCL2 Ubuntu builders

Taking the [chef/bento](https://github.com/chef/bento) repo as an example.

I recommend you start by reading the build.pkr.hcl file and the
comments/description there.
