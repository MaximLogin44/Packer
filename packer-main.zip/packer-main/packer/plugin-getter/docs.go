// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: BUSL-1.1

// Package plugingetter defines means to download and install plugins.
package plugingetter
